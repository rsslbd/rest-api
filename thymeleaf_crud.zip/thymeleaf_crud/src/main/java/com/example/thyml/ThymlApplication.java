package com.example.thyml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymlApplication.class, args);
	}

}
