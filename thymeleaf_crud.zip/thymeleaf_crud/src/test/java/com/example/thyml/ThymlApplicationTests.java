package com.example.thyml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymlApplicationTests {

	@Test
	void contextLoads() {
	}

}
