package com.home.project.dto;

public class PostDTO {
}
