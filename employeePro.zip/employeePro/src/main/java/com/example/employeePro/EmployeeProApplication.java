package com.example.employeePro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeProApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeProApplication.class, args);
	}

}
