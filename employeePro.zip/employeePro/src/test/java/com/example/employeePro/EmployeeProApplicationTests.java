package com.example.employeePro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeProApplicationTests {

	@Test
	void contextLoads() {
	}

}
