package com.example.employeeDt.service;


import com.example.employeeDt.entity.Employee;
import com.example.employeeDt.repository.EmpRepo;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@org.springframework.stereotype.Service
public class Service {

    @Autowired
    EmpRepo empRepo;


    public List<Employee> findAll() {
        return empRepo.findAll();
    }

    public void save(Employee empNew) {
        if (empNew.getId()!= null){
            empRepo.findById(empNew.getId())
                    .map(old -> {
                        old.setDesignation(empNew.getDesignation());
                        old.setName(empNew.getName());
                        old.setGender(empNew.getGender());
                        old.setName(empNew.getName());
                        old.setSsc(empNew.getSsc());
                        old.setHsc(empNew.getHsc());
                        old.setBsc(empNew.getBsc());
                        old.setMsc(empNew.getMsc());
                        old.setEmail(empNew.getEmail());
                        old.setBirthDate(empNew.getBirthDate());
                        old.setAddress(empNew.getAddress());


                        return empRepo.save(old);
                    })
                    .orElseGet(() -> {
                        return empRepo.save(empNew);
                    });
        }else {
            empRepo.save(empNew);
        }
    }

    public Employee getById(Long id) {
       return empRepo.findById(id).orElse(new Employee());
    }

    public void delete(Long id) {
        empRepo.deleteById(id);
    }

}
