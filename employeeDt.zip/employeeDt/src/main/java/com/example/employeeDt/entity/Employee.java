package com.example.employeeDt.entity;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;


@Entity
@Getter
@Setter
@ToString
public class Employee extends BaseModel {

    private String designation;
    private String name;
    private String gender;

    private Boolean ssc;
    private Boolean hsc;
    private Boolean bsc;
    private Boolean msc;
    private String email;

    private String birthDate;
    private String address;
}
