package com.example.employeeDt.DTO;

import lombok.Data;

@Data
public class EmployeeDTO {
    private Long id;

    private String designation;
    private String name;
    private String gender;
    private Boolean ssc;
    private Boolean hsc;
    private Boolean bsc;
    private Boolean msc;
    private String email;

    private String birthDate;
    private String address;
}
