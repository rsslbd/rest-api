package com.example.maven_jstl_template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenJstlTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
