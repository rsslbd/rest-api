package com.example.maven_jstl_template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenJstlTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenJstlTemplateApplication.class, args);
	}

}
