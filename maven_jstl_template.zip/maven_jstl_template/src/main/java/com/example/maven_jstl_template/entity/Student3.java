package com.example.maven_jstl_template.entity;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Student3 {

    private Long id;
    private String name;
    private String gender;
    private String dob;
    private String jsc;
    private String ssc;
    private String hsc;
    private String subject;

}
